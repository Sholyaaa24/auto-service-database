-- Example analytical queries (not present in the source model).
-- Run them against your own database once you have test data.
USE `autoservice_db`;

-- All orders with linked client and car
SELECT *
FROM `v_order_details`
ORDER BY order_date DESC
LIMIT 20;

-- Number of vehicles for each client
SELECT c.id_client, c.full_name, COUNT(car.id_car) AS car_count
FROM `client` AS c
LEFT JOIN `car` AS car ON car.id_client = c.id_client
GROUP BY c.id_client, c.full_name
ORDER BY car_count DESC;

-- Total number of units of each service in orders
SELECT s.service_name, SUM(os.quantity) AS total_quantity
FROM `service` AS s
JOIN `order_service` AS os ON os.id_service = s.id_service
GROUP BY s.id_service, s.service_name
ORDER BY total_quantity DESC;
